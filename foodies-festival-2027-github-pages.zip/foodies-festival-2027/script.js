(() => {
  const menuButton = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.primary-nav');

  if (menuButton && nav) {
    menuButton.addEventListener('click', () => {
      const isOpen = menuButton.getAttribute('aria-expanded') === 'true';
      menuButton.setAttribute('aria-expanded', String(!isOpen));
      menuButton.setAttribute('aria-label', isOpen ? 'Open navigation' : 'Close navigation');
      nav.classList.toggle('is-open', !isOpen);
    });

    nav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        nav.classList.remove('is-open');
        menuButton.setAttribute('aria-expanded', 'false');
        menuButton.setAttribute('aria-label', 'Open navigation');
      });
    });
  }

  // Gallery lightbox: image files are intentionally supplied by the site owner.
  const lightbox = document.querySelector('.lightbox');
  const lightboxImage = lightbox?.querySelector('img');
  const closeButton = lightbox?.querySelector('.lightbox-close');

  document.querySelectorAll('[data-gallery-image]').forEach((tile) => {
    tile.addEventListener('click', () => {
      const imagePath = tile.getAttribute('data-gallery-image');
      if (!lightbox || !lightboxImage || !imagePath) return;

      const image = new Image();
      image.onload = () => {
        lightboxImage.src = imagePath;
        lightboxImage.alt = tile.getAttribute('aria-label') || 'Foodies Festival photograph';
        lightbox.showModal();
      };
      image.onerror = () => {
        tile.querySelector('span').textContent = 'ADD IMAGE FILE';
      };
      image.src = imagePath;
    });
  });

  closeButton?.addEventListener('click', () => lightbox.close());
  lightbox?.addEventListener('click', (event) => {
    if (event.target === lightbox) lightbox.close();
  });

  // Social and app destinations are placeholders until the owner supplies URLs.
  document.querySelectorAll('.placeholder-link').forEach((link) => {
    link.addEventListener('click', (event) => {
      if (link.getAttribute('href') === '#') {
        event.preventDefault();
        link.setAttribute('title', 'Add the official URL in index.html before publishing');
      }
    });
  });
})();
